# build-segment

Description: Executes the next chunk of work safely.

## Step 1
Invoke `build-orchestrator`.

## Step 2
Stop after completing 1–3 tasks max.
