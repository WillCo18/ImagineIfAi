# project-plan

Description: Produces Blueprint: contracts, schema outline, skills/MCP list, and executable task plan.

## Step 1
Invoke the `planner` skill using `architecture/research.md` + intake answers.

## Step 2
Write/update all required planning outputs.

## Step 3
Stop and request explicit Blueprint approval before any tools code.
