# deploy

Description: Deploys using the chosen platform skill.

## Step 1
Read `gemini.md` for the chosen deployment target.

## Step 2
If Vercel, invoke `deploy-vercel`.
Else, create a deploy skill stub `.agent/skills/deploy-<target>/SKILL.md` and stop for approval.

## Step 3
Record deployment evidence.
