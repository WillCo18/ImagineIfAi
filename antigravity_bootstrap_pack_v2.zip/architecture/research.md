# architecture/research.md

Focus keyword: **anti-gravity**.

Filled by `research-first`.
