# architecture/skills_needed.md

Focus keyword: **anti-gravity**.
