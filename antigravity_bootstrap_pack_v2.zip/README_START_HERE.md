# anti-gravity Neutral Project Runner (v2)

Focus keyword: **anti-gravity**.

Run these workflows in order:
1) `/project-intake`
2) `/project-plan` (stop for approval)
3) `/project-link`
4) `/build-segment` (repeat)
5) `/deploy`

Generated: 2026-01-28
